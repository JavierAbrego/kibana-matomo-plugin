import $ from 'jquery';

window._paq = [['trackPageView'], ['enableLinkTracking']];
window._paq.push(['setTrackerUrl', '//matomo.techmon.3stripes.net/matomo.php']);
window._paq.push(['setSiteId', 42]);
require('./piwik');
$(document).ready(function () {
  function trackPage() {
    const page = window.location.hash.substr(1).split('?')[0];
    const matomoArgs = [
      ['setCustomUrl', page],
      ['setDocumentTitle', page],
      ['trackPageView']
    ];

    matomoArgs.forEach(function (args) {
      global._paq.push(args);
    });
  }
  //global.Matomo.addTracker('//matomo.emea.adsint.biz/matomo.php', 999999);
  global.onhashchange = trackPage();
  // trackPage();
  console.log('Matomo is loaded successfully.');
});
